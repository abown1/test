# 2026-11-07 靈田最小修復＋截至13:39 Asia/Taipei已知bug去重隊列

## 本批完成（本機source，未部署）
- g4.js：務農接既有assignJob管線，驗建成靈田／容量，正常清除舊task與室內狀態；econ_buildings.js不再直接繞過手令鎖寫job。玩家新的務農令覆蓋舊採集令；自動派工不能繞過舊手令。
- g23.js：睡眠保存原jobB，醒來恢復原工作與建築；無法啟動休息也還原jobB。新玩家指令沿既有assignJob取消舊睡眠續工狀態。
- **修正舊診斷**：立即snapshot/applySave在修前已保留farm及jobB，不存在本批可證的獨立「存檔白名單不含farm」缺陷；沒有改白名單。舊報告存讀後null可能是先前掉職後存入null。本批另測「住房睡眠中存讀→醒來恢復務農」通過。

## 證據與限制
- /tmp/xw_farmfix_20261107/before_house.json：修前手令恢復把farm改gather；休眠jobB改成住房243，醒來farm被清為null。after_house.json：保存原靈田232，醒來farm/232。
- checks.js / checks.json：14/14定向斷言，頁面錯誤0；覆蓋自動不能越手令、新手令取代、容量與非法建築、住房睡眠中存讀與醒來、醒來doJob、睡中改guard、新save/load。真headless Chrome載入完整私有build，但建築／人物以fixture建立，呼叫實際產品函式；不是自然建造閉環、真人實點、真雙機或全玩法回歸。
- 三改檔 node --check通過。完整build只在/tmp/xw_farmfix_20261107/proj，測試用__EV只在私有HTML，不在產品source。
- 舊farm2.js 600秒雙模式重跑過長，已中止，不算完成；本輪用小案例代替，不續跑大矩陣。
- before/是動前備份；farm_fix.patch是完整diff；before.sha256/after.sha256。官方build.py與固定b ZIP hash逐字相等，未重建共享site、未動SW、未發布公告／部署。

## 去重隊列（只是現有台帳與最新封存交接整理，不宣稱重新全查）
### A 已有最終b修復／不重複開發，仍區別玩家驗收
- B03戰鬥移動、B23招募按鈕換DOM漏click；B38一般／客機傳送安全落點及quick付款v2；B74離房身份／trade-wait保live；B98–100旅行／副本現場與資產ID存讀。
- 功法卷軸id→nextItem NaN、技能欄在線讀檔、玩家道侶雙修、索敵／防擠／副本不派工已有最終修煉封存測試；不要因舊BACKLOG再寫一次。
- 任務堂L108倍率lookup已修（econ_task 10d6fb9cbcf0）；付款交錯收入被undo抹除／假done已由group＋staged最終接線取代。經濟13:04「待net驗」被net13:11 VM17/0後報覆蓋，不再列為尚未接線；新BC/UI仍未驗。
- 三品顯示全0舊報告已在11:5x修正為fixture原值為0；不是目前已證UI故障。

### B 最新去重狀態（截至2026-11-07 13:50 Asia/Taipei；各批細節與hash見下）
1. B1 treasury-off舊薪橋：第二批已修live帳戶替換與到期排程，17/17定向驗證。舊wallet/mirror、歷史雙到期矛盾、部分例外仍保留failclosed，不能自行補發或裁資產。
2. B2 quick傳送conflict：第二批已加玩家可見取消／可能扣款提示，7/7定向驗證；既有恢復限制不變，不自動退款或清receipt，真人UI/BC仍未驗。
3. B3按鍵重綁提示：第三批證實#xsm漏掃與交換鍵級聯並最小修復；6個按鍵/存設定小斷言通過。只同步既有提示，不改按鍵機制。

### C 歷史回報未重現／待玩家驗證，不等於已修或可直接改
- B32/33副本怪物仇恨、B34–36聯機進出／死亡、B39遠屋防衛、B41首領發呆、B43技能過遠、B45後撤、B49擊退、B54/55封屋施工／路縫、B56送禮移動、B57副本擋路、B58缺礦發呆。
- B66/68/69/70/71/72/73/76聯機暫停／流暢／事件／經驗／名單／靈根／室內；B75離線過快現行有限制且測不出，不重做規則。
- B89/91/92面板遮擋，B59凡人靈石、B60護陣回復、建築升級實點、其他建築實玩與礦場／比武被污染的舊fixture、武道館倍率公式對齊。
- 新staged網路完整UI／新BC／真人雙機、自然打造→俸祿→買裝、全存讀玩家閉環未驗；不可用舊22/0或本批14/0填PASS。
- 美術／設定質感／B04/B24等是擱置或偏好，不擴成新製作。

### D 缺規格／未實作功能／保護行為，明確不在bug小修擅做
- #115新生兒繼承、幻境試煉塔入口、分宗、室內六互動、雲存檔跨帳號／部署、新法陣與丹藥機制不新增。
- 採集經驗品級曲線、未來源卷軸歸屬、贈回／遺物繼承、工錢／數值比例等不猜。
- grLegacy.pick=res歷史不能無損回溯、個人wallet/mirror矛盾、stage pending／partial debit／journal鎖無自動裁決政策：保留failclosed，不清journal、不採舊JSON、不自動退款／解鎖；一般舊檔vault採信政策其實已定，勿再誤報全部政策未定。

## 本批改檔完整SHA256
- g4.js: 60852fb93052b0311fbb08b95e1c1223748bcd9e176140a646fd9434ab91b723
- g23.js: c16e228bf4ec2672b41b2a75a044edb87efb3e5205e7d9e75b92424300e6829f
- econ_buildings.js: f83f1c65a28f93e8e109856ea580f06869cbb1560b2c0bff3c1ef1025fda8726


# 第二批續作：2026-11-07（Asia/Taipei）B1/B2狀態更新
以下覆蓋上方B1/B2的「未修」。本批仍本機未部署，沒有公告或叫醒其他bot。

## B1 薪橋：已作最小安全修復，歧義帳保留阻擋
- 修前實證：正式wallet=10，舊橋發出1下品後公庫299，但還原wallet仍10、人物mirror已11；同時帳矛盾仍把到期300推至600。before_result.json保留兩個FAIL。
- econ_gtrade.js不再替換live vault/wallets。整批薪資參與者先驗正式wallet四品／ledger／人物mirror一致、live公庫alias正確、沒有未決交易帳鎖；缺失或矛盾只拒絕，不seed、不選帳、不碰carry/欠薪/到期日。
- 一致帳沿用原econPayMonth、econFeePay、職位／金額／小數carry／欠薪與貢獻後備，不自訂補發。只在同步呼叫原薪資公式期間暫設treasury=true；原事件通知延至恢復false後再送，避免模式期間的外部回呼重入，沒有開稅／保養。
- 只有原薪資流程完整結束才推下期，零現金但carry變動也算一期完成；成功同步off與on既有期限，正常模式切換不再同一期二發。歷史兩個已存在但不同的到期值保持阻擋，不猜哪期該補發。公開XW.gt.stipend()也不容許未到期重發。
- 真異常可能已部分發放，保留實際錢／ledger／carry，flags.gtStipendError只作持久failclosed標記；econ_core.js兩個守門讓切回treasury-on或直接payMonth也不能重發或吃掉到期。沒有自動退款／重試／新恢復流程。
- 待決一句：舊檔wallet10/mirror11及兩套歷史到期不同時，需有來源證據指定權威帳／應發期；目前不自動裁決。部分發薪例外也須人工核對，不能刪marker冒充修好。
- 定向VM **17/17**：真core/grade/gtrade薪資與snapshot/applySave入口、到期單發、零現金carry單算、live身份及高品資產、ledger、off/on/off、缺失／矛盾／pending鎖不改狀態、事件重入、付款後例外不重發及存讀保留。平台與人物／資金為fixture，不是自然賺錢或真人財務驗收。

## B2 quick conflict：已補玩家提示，不改既有金融保護
- map_safe_land.js僅在原currencyConflict診斷入口加入toast。
- capture失敗：「帳務資料無法驗證，已取消傳送；請保留存檔並回報。」
- restore/commit失敗：「傳送未完成，帳務狀態需核對（可能已扣費）；請勿重複操作，保留存檔並回報。」不宣稱未扣費或已退款。
- 實際quick＋完整core/grade子集VM 7案：新增提示斷言修前 **2/7，5 FAIL**，修後 **7/7**。交錯收入案例仍為200-5+7=202且保留grant/charge ledger、位置回復、run取消；沒有把conflict變成功、沒有退款清receipt。成功與可證完整還原例不誤發帳務conflict提示。
- 既有恢復界線：run取消／角色任務還原及currencyConflict只讀診斷仍在；不具備新的玩家自動對帳恢復流程，沒有聲稱可用按鈕解鎖。
- 舊harness因缺applySave平台stub及初始化vault仍100而失敗的初跑保留（quick_*corrected及初始檔）；只修fixture boot並明設初始xia=0，原預期200/195/202/207及金融斷言均未放寬。測試toast呼叫，不是桌面實點驗收。

## B3與其他剩餘
- 第二批當時B3僅定位，當時未修；已由第三批下述確證與修復覆蓋，勿重複開工。
- 上方C歷史待玩家驗證、D缺規格／新功能與failclosed限制不變。沒有全財務矩陣、全玩法或真雙機測試。

## 第二批證據及不變項
- /tmp/xw_stipendfix_20261107/：before/備份、before/after.sha256、stipend_quick.patch、runner.cjs/cases.js/focused_result.json/focused.log、before_result.json、quick_notice.js與quick_before_final.jsonl/quick_after_final.jsonl。
- 全build只在上一批/tmp/xw_farmfix_20261107/proj，完整headless頁面啟動並原靈田14/14再次通過、頁面錯誤0；boot_farm_regression.log。三改檔node --check通過。
- g4/g23/econ_buildings三份靈田改檔hash、官方build.py、固定b ZIP均與本批動前逐字相等；未動共享site/SW/部署。

## 第二批改檔完整SHA256
- econ_gtrade.js: 9df3910776ee60994c4b51499b12fe0979ed04dd88099e1645dc8de6eea8416c
- econ_core.js: 7e253c42f53de875e51113640a1efc852e9815fe9f7755532cdf36295f7bf6e0
- map_safe_land.js: f7a76beecd2f66c9bfa119cc08f7dc9bfe62af527ca4f14b8c7614f9f407828e


# 第三批續作：2026-11-07 13:50（Asia/Taipei）B3與兩個歷史卡關候選

## B3 已證實並最小修復（只改g21.js顯示同步）
- 透過真openSettings→v173Bind(help,F8)→v173Act(apply)：實際mapping已是F8→KeyH、設定鈕顯示F8，但已被工具列搬到#xsm的「說明」仍顯示(H)。根因為既有x47KeyHints掃描#topbar但漏掉搬到body下的#xsm。
- 已把#xsm納入既有顯示同步，不改鍵盤指派/事件邏輯。修後說明顯示(F8)，真鍵盤舊H不開、新F8可打開help；prefs重新載入仍顯示F8，還原預設後恢復(H)。
- 同時證實原x47KeyText多輪regex會級聯：交換J/H時「按 J鍵」變成原本J，應是H。改為單次從原字串換算，不重改替換結果，數字技能鍵的b/kbd/按鍵標示同規則。
- 證據：/tmp/xw_keyhintfix_20261107/before.json、after.json、probe.js；修前有實際設定mapping/DOM不一致，不是單看過時BACKLOG或為湊綠改斷言。

## C候選定向核對：兩項未重現，沒有改玩法
- B54施工／升級卡關候選之「大殿Lv1限制房屋升Lv2卻無提示」：真startUpgrade回false，捕捉到「主城未升級（需大殿 Lv2）」，資產及upg都沒變。此分支未重現故障；不代表已驗完整密集封屋/路徑施工。
- B58智能缺礦發呆：真doJob，完整枯竭fixture（amount=0且gone=true，符合removeNode正常不變式），無可採資源時清gather→null、smart→false，未卡採集職務。沒有改碼；原始玩家場景仍待補具體存檔/站位/礦點狀態。
- 初次fixture只把amount設0卻保留gone=false，破壞正常枯竭不變式，找點函式仍可選它；另鍵盤焦點仍在UI輸入框時不應觸發重綁事件。修正fixture／輸入焦點後原預期不變，失敗紀錄保留checks_initial_fixture_fail.json，不把這兩個量測問題算產品修復。

## 最小驗證與限制
- checks.js/checks.json：headless Chrome完整私有build **8/8，pageerror0**（6個按鍵/提示與2個卡關候選斷言）。設定操作走真產品函式，鍵盤按鍵用Playwright實際事件；建築與枯竭世界為控制fixture，不是自然長流程或真人驗收。
- node --check g21.js通過。私有/tmp build；未動共享site/SW、build.py、固定b ZIP；上兩批6檔hash與本批動前逐字相等。
- 備份/diff/hash：/tmp/xw_keyhintfix_20261107/before/g21.js、key_hint.patch、before.sha256、after.sha256。
- 本批檢視的下一候選沒有新增「確證現在仍壞且能按既有規格小修」項；仍有C歷史場景、真人雙機與UI待驗，不等於全部bug已修完。保持舊wallet/mirror／歷史到期矛盾／部分薪資例外failclosed，沒有新增對帳或補發。
- 下一步宜由玩家具體回報/存檔補足仍未重現的卡關場景，勿無限重跑全盤矩陣或重寫已有b修補。

## 第三批改檔完整SHA256
- g21.js: 136f25ed46752b09eb4c7418a8fbf2e564c118e664ad9f5fd710987bad6c620c


# 三批整合上傳候選c（2026-11-07T13:53:42.223154+08:00，Asia/Taipei）
- 狀態READY_NOT_DEPLOYED，無部署／Discord，並非所有bug已修完。來源與最終b manifest比對332檔：325完全相同，僅既有三批7檔有預期差異，無額外漂移。
- 獨立私有build：/tmp/xw_bugfix_20261107c/proj；原build.py SHA256固定956a43ba69602fc7a326ca0077daa0a8ee7b6b77ecd9716a694334ff57aefa73未改，只私有副本D改輸出路徑。
- ZIP路徑：/tmp/xw_bugfix_20261107c/site_v045.zip
- ZIP SHA256：f622d9bc04b27575bc463aba9d63a628ce6bdacb4a549ecffaf877fe3cae9e21
- 同b的203檔平鋪ZIP布局，index.html在根；內容僅index.html與service-worker.js變，僅發布copy CACHE升xianwu-v0.5-20261107c；正式b ZIP與其203檔均逐hash未變。
- gate.json真未插樁發布HTML boot/render、IndexedDB手動m0存讀與頁面reload再讀、非零資源/物品/國庫/玩家wallet帳本守恆：5/5，pageerror0/requestfailure0。測試瀏覽器造樣資產，未寫入發布檔；不含真人雙機／全玩法驗收。
- 首輪量測失敗原樣保留：snapshot對res的live參考跟著測試+17變化，另存讀正常補feeCfg/空groundGear非資產差異；改deep-copy及資產範圍後過，沒有改產品或放寬資產相等要求。
- 原三批針對性證據復用，不重跑大矩陣。完整來源hash、發布hash、七檔前後hash、ZIP hash與剩餘分類都在/tmp/xw_bugfix_20261107c/READY_NOT_DEPLOYED.json及source_manifest.json、artifact_manifest.json。
- 剩餘：C歷史場景未重現／需玩家條件；BC/UI／真人雙機未驗；wallet/mirror矛盾、歷史不同期程、部分薪資恢復仍failclosed待政策；未實作功能不新增。


# t1330u後續／t1331u改交測試：工作邊界交接
- 更新時間：2026-11-07T13:59:07.625604+08:00（Asia/Taipei）。收到「剩下給仙武測試跑」後停止擴大C歷史重現與聯機驗收，沒有另啟測試或人力。
- 本輪實際僅讀原BUG_LOG_FOR_QA.md主表症狀及econ_gtrade.js的wallet／到期／partial guard定位；尚未建立新重現案例、尚未證實正常操作會自造帳目矛盾，也沒有新增已修結論。帳目根因待測試提供可重現操作/存檔後接修，不因現有guard存在就假定安全全通過。
- 正在修改的產品檔案：無。本輪七檔source與c source_manifest.json全部一致，c ZIP／build.py／SW／sharedsite未改、未部署、未發公告。
- 避免重複：已完成三批及c gate見上文。尤其B54先前只測「大殿Lv1限制升級」提示，**未測原回報四周封屋**；B58只測正常amount=0/gone=true全枯竭無候選，**未測原回報附近缺鐵但其他遠礦/智能調度**。這兩個歷史原案例仍留測試核對，不能因小分支通過就關單。
- 仙武測試可隔離使用固定c /tmp/xw_bugfix_20261107c/site_v045.zip；C剩餘逐項症狀以_dev/v45/BUG_LOG_FOR_QA.md各B號為準，原台帳「待回測」不等同PASS。原C清單與真人聯機均由測試接續，本executor本輪未跑任何一個新C/聯機案例。
- 財務仍待條件：歷史wallet/mirror矛盾、雙到期不同、partial薪資例外；保留failclosed、不選資產權威、不自動補發/退款/清鎖。請提供觸發前後存檔、操作序列、treasury開關狀態與錯誤原因/帳本，若能確證正常操作自造矛盾再修產生原因。
- 當前無新增確證待修根因；停在現狀，等仙武測試真bug後續修補，不擴scope。


# t1338u 練武變採集增量修補（2026-11-07T14:38:52.894495+08:00，Asia/Taipei）
- 詳報：/tmp/xw_trainfix_20261107/REPORT.md。b與c都有缺館偷改gather、tick強迫採集與手令train→gather特例，已在c source上最小修正兩檔，不涉及其他歷史測試。
- 純離線函式修前3/9、修後13/13；無瀏覽器/網路/8765存取，UI/完整frame/真人聯機與玩家實際館舍條件仍未驗。
- 固定c ZIP不含新修補，不能當成已交玩家；本機source新增兩檔差異，後續整合須以此報告為準。未build、未部署。
- _dev/v45/econ_buildings.js after SHA256 4c64dd08fa0fb4d3409a32dc444118c3420a362c81c43bd2aacd8914110591da
- _dev/v45/econ_manual.js after SHA256 672627aca0fca3e4476eb9810cd9050b0bff2c287b856e5d0f61afe63089eebb


# t1339u 遊玩卡頓第一批（2026-11-07T14:41:08.271509+08:00，Asia/Taipei）
- 詳報/tmp/xw_playperf_20261107/REPORT.md。確證多靈田每次產率計算重掃units，改為單次局部Map；不跨tick快取、不改收益/AI/存檔頻率。
- 純離線10/10、練武13/13複驗；合成19有效田/200單位訪問3800→200，93田/1000單位93000→1000，非FPS或玩家卡頓已解證明。
- 僅econ_buildings.js在練武修補上增量，最新SHA256 9e228a40b3a47404dd11b6c6aa5c9c876b5da361fb051487cfa3367ecaefda8f；其他來源不變。固定b/c不含增量、未build/部署；待玩家裝置/單多人/存檔定位其餘熱點。

- t1340u/14:40確認電腦單人後補查：主迴圈/AI尋路/DOM/自動存檔/單人同步；沒有新增改碼。guards.json純離線5/5：單人netPulse略過工作、存檔設定節奏與busy/title防重入守門成立；不是實際frame/磁碟/網路效能數據。詳報同上，待存檔/卡頓情境再定位。


# t1341u 全程式覆蓋第一批（2026-11-07T14:45:14.483552+08:00，Asia/Taipei）
- 詳報/tmp/xw_codepass_20261107/REPORT.md。module_coverage.json明列126組裝JS模組：12局部已查/定位、114待覆核，非整體PASS。
- 本批僅g23敵名牌跨簇查找加本次build物件索引，保留動態簇fallback與所有座標/分組/文字/碰撞語義。離線8/8；100簇200敵查找成員訪問20100→300，非FPS數據。
- 中文高頻按鍵靜態5項成立，沒有新增確證錯綁；倉庫/背包完整鏈留下一批。事件重綁有守門，未刪late install/公開API/遷移/net保護。
- g23.js最新SHA256 1c61dc4523319e6b83cb30ca53fbde206b3a372735d028e67fb5933ae8f752a0；其餘來源相較上批逐hash相同，原c/練武/靈田優化保留。固定b/c ZIP與build.py不動，未build/部署。下一批render/UI常駐運算＋倉庫/背包操作契約；全程卡頓主因未定。


# 全程式優化第二批（2026-11-07T14:47:56.824366+08:00，Asia/Taipei）
- 詳報/tmp/xw_codepass2_20261107/REPORT.md；同一覆蓋清單更新為22模組局部已查/定位、104待查，本輪1模組修補，兩輪codepass累計2。
- g19頭像列0.3s更新內多次unitById線性掃描改同render局部索引，保留first/strictID；純函式9/9含倉庫→隨身丹藥四案數量守恆，靜態render接線其餘內容逐字一致。
- 中文裝備/卸下/分解/拿取與後載私人背包、pending/client守門已局部查核，未確證新錯綁。容量header TUNE.invCap與各入口econInvCap的權威候選留下一批，未猜規格。
- g19最新SHA256 04b71e7ad8297c77c6b44c14fa2e080f7aa9043ccbd9f3ccf22113cdf58fcbfd；g23索引、練武、靈田與其他source相較上批hash未變。固定b/c、build.py/sharedsite/SW不動，未build/部署，無瀏覽器或FPS驗收。


# 全程式覆核第三批（2026-11-07T14:50:09.250783+08:00，Asia/Taipei）
- 詳報/tmp/xw_codepass3_20261107/REPORT.md。同清單累計24局部已查/定位、102待覆核；本批g22一檔改動。
- y194Lay僅寫style前的同次矩形讀取共用結果，18請求→10ID；後半寫入後fresh量測不變，純memo5/5及接線源還原等價。沒有執行DOM/瀏覽器或卡頓造例驗收，不報FPS。
- 容量header固定TUNE.invCap而操作入口selected u/player計上限不一；既有規格未定共用S.inv權威。精確待決「共用容量依主角還是當前操作角色？」未改規則或假稱已修。
- g22最新SHA256 e2f5ef95fea22b1854adc47efe196e4f2027ded15128d8e1cbaaae37c07d9011；其他source/g23/g19/練武/靈田修補保留，固定b/c/build.py/sharedsite/SW不動，未build/部署。


# 全碼覆核第四批（2026-11-07T14:52:39.137037+08:00，Asia/Taipei）
- 詳報/tmp/xw_codepass4_20261107/REPORT.md；累計30局部已查/定位、96待查；本批產品改動0，完整332來源hash與上批相同。
- 新查world解鎖poll/boot動態遷移、FX/Combat常駐鏈；既有關閉守門純函式3/3，無可證可刪項，未造卡頓/FPS結論。
- capacity_entry_matrix.json列現行各入口；原規格窄查未找到共用容量actor定案。供parent問：A共用S.inv統一依主角（須確認卸下規則變更）；B保留主角收納/所選角色卸下差異，UI分別標容量。兩案都保留既有超額物品/pending/private隔離，未選未實作。
- 原b/c/build.py/sharedsite/SW及全部前修不動，未build/部署。下一批按未查populate/tick鏈前進。


# 第五批：容量B已定案並落實（2026-11-07T14:55:41.531553+08:00，Asia/Taipei）
- 使用者14:53選B，已不再待決；詳報/tmp/xw_codepass5_20261107/REPORT.md。行囊/總倉分別標拾取買回主角容量、共有卸下行囊角色容量；卸下tooltip區分私有/共有去向。原容量/資產/私有背包/pending不改。
- 純顯示契約8/8，源路由/算法保持與三檔syntax通過，未UI/瀏覽器/FPS驗收。
- 累計34模組局部已查/定位、92待查；新查active cities/party/防衛/cult tick鏈，本批無新的確證效能修補，沒為湊數刪碼。
- _dev/v45/econ_store.js after SHA256 528fd0ae3e99ec0d1c9ee484c3a8fd18b921487d6c2b8ebdd87aee3800242bb8
- _dev/v45/g14.js after SHA256 0c99c25729d017a9ffc921b0d9c3f10be32de000331debce6242b62a10005710
- _dev/v45/g20.js after SHA256 362a49957b43021100cb27ba0aa9f19502854561f65f54f52aa7c0177f550bec
- 其他來源與先前修補保留；固定b/c/build.py/sharedsite/SW不動，未build/部署。下批未查map_sects/travel鏈優先。


# 全碼第六批（2026-11-07T14:58:17.229633+08:00，Asia/Taipei）
- 詳報/tmp/xw_codepass6_20261107/REPORT.md；累計39局部已查/定位、87待查。本批跨sect/travel/co-op/入口/網路拒絕五模組局部前進。
- map_enemies同次sanitize相同target ID查找memo，仍逐敵驗活性/座標、保留建築/home/所有掃描，無跨tick快取。離線6/6完整狀態+n等價，100共享目標查找呼叫100→1，非FPS數據。
- 前往中文鏈為走入口再入場，聯機飛行拒絕是既有保護，未錯當錯綁；容量B保持。
- map_enemies最新SHA256 d7c65035df690b0bfef820ea5eb21b7849a6d735759be0a4091f6c023a1e2606；其他331來源不變，固定b/c/build.py/sharedsite/SW不動，未build/部署。下批未查mounts/qi/gongfa鏈優先；全程卡主因未定。

# 全碼第七批（2026-11-07T15:08:20.513002+08:00，Asia/Taipei）
- 連續處理40個原先待查模組的具體來源/資料切片，累計79/126有局部已查或定位紀錄、47尚待來源覆核；不是79整檔通過，舊僅定位標籤保留。詳 `/tmp/xw_codepass7_20261107/REPORT.md`，同coverage JSON已更新。
- cult_unclump保留每tick/原分離/有效接觸輪與最多8輪，只省已無接觸固定點的空跑輪；30遠距單位豁免查詢3720→465，200組原新資料/碰撞callback順序相同，含真xmvOn逾期清理。非FPS。
- cult_fly每tick重讀真狀態但同值不重寫text/display，普通JS值格100次兩setter各100→1；不改御劍/落地handler/耗氣/頻率。
- map_cave_prompt修確證asked先被面板阻擋耗掉：阻擋保留未詢問，關面板下一tick恰好詢問一次；提示/取消離開重入/client不變。map_dgart_draw去兩次shift、既有超額cache一次回限；正常單次新增留存等價。
- 離線18/18，40/40來源獨立語法通過，非DOM/Canvas/UI/組裝boot/FPS/真存讀/真聯機驗收。固定b/c ZIP只讀均仍有四項舊碼，不代表線上已修。
- 332來源清單僅四檔變動、328檔不變，完整before/after SHA256、備份/diff/證據在本批資料夾；保留map_enemies、容量B與此前全部修補。build.py/sharedsite/SW/固定b/c ZIP未改，未build/部署/公告。仍無玩家全程卡頓主因量測定案；尚待47與具體範圍見報告，不把候選或定位當PASS。


## t1341u/t1342u/t1343u 第八批：山賊與首輪收束
- 時間：2026-11-07T15:23:49.673720+08:00（Asia/Taipei）；詳細交接 /tmp/xw_codepass8_20261107/REPORT.md。
- 確證到期流浪者抵達投奔可越過寨成長目標10/12：真updateWanderer+最終joinFaction包裝fixture 10+30→40；入口與本機v040起/b/c逐字相同，非新timer回歸證實。滿寨投奔政策欠規格，未砍率/加猜測上限/清敵。
- 唯一新產品修補g23：先排除遠距/非更近NPC，再做純vById；512 strict fixtures狀態/動作等價，遠距100×64查找6400→0；不是FPS根因判定。SHA256 57712f8074c581306c2bccb79ab81a628adb3d4bd4bcfbe6ca70faaf08686622。
- unclump保留前修，240組真tile collision/xmvOn/XTL getter/明列passes等價；7/7離線組通過。
- 首輪47新查+4舊僅定位補實讀，126/126有效局部切片、非整檔PASS；自c13檔完整hash清單 cumulative_since_c.json。所有前修、容量B、固定b/c/build.py/SW保留；不build部署公告/不瀏覽器繞路。

- 第八批補記：另查g19賞金獵人bh=1，非普通山寨raid；真到期tick窄測在保留舊活體且不跑中間AI時可3波18名，未證正常世界無限累積，不改玩法。細節/舊版函式同源比較見第八批REPORT與第7組checks。


## t1344u 新d獨立封裝交接
- 2026-11-07T15:32:00.195406+08:00（Asia/Taipei）；實際獨立私有build完成，不再只是前報告。ZIP /tmp/xw_release_20261107d/site_v045_20261107d.zip；9350606 bytes；SHA256 8c7a3497ca0c2a8cc418f33668dda02e3f1b7afdee46313cc733fe4fe8c894dc。
- 完整交接 /tmp/xw_release_20261107d/RELEASE_REPORT.md；332原輸入未動，自c13檔全量已入包，203檔與manifest/ZIP一致；d CACHE xianwu-v0.5-20261107d-152729。
- 無新增產品修補：真collide/helper反例顯示輪首靜態空間索引會漏後續新接觸，座標/碰撞callback不同，未倉促導入。密集全配對成本仍未解，不保證不卡。
- 10純離線harness、10包裝檢查、4組裝/所選序列化檢查通過；真boot/UI/IndexedDB存讀/多人/FPS未驗。保持既有前修與容量B、固定b/c、官方build.py/SW/sharedsite；未部署/Discord。滿寨投靠政策與玩家精確舊版同場景仍缺。


## t1347u 第九批：d後密集碰撞查詢
- 2026-11-07T15:40:48.466005+08:00（Asia/Taipei）；本批source-only唯一改cult_unclump，同pair重用移動狀態首讀，不跨pair/callback缓存；詳細 /tmp/xw_codepass9_20261107/REPORT.md。
- SHA256 ee76e23ac9c13ef14dadd76d9586ca024a80ab8315269d4b2e11b351b907c4ee；d舊來源備份/完整332 manifest/patch於同目錄。6組離線通過，240例真helper/tile＋動態callback共12104次觀察等價；混合128密集195584→130048 helper，同袍活令260096→130048；碰撞callback/配對/頻率照舊，非FPS增幅。
- 無空間索引/關功能/減敵/改資產；同陣營idle及稀疏helper數不減，O(n²)密集配對仍在。非法NaN/Infinity曾令舊native tile-loop不終止，已隔離fixture並記錄，未證合法遊戲觸發。
- 331輸入不變，固定b/c/d ZIP與d copy203檔未動；本批新source尚未入d，不build/部署/公告，官方build.py/SW/sharedsite不動。山賊政策未猜，面板/尋路本段無新增。


## 第十批（2026-11-07T15:56:24.270667+08:00 Asia/Taipei）來源後續，非新發布包
- 山寨投靠原先可繞成長目標；依新授權以原年齡目標拒收，不清現存/超額、不動raid/bh/資產/頻率。30同tick只收最後1位；40舊成員全留；滿後在途沿原改選/等待，150秒目標開位可再投靠。overflow無目的地保留原物件，不能為了上限丟角色；自然生成仍由原wanderCap停止。
- g13中文入口「精英守衛＋守門天將」→「精英守衛＋試煉王」，候選patch逐字相等；無境界/數值/獎勵/強度變更。
- 10組真函式離線證據、126片段parse；非UI/FPS/真存讀或實戰通關。第九批碰撞helper及先前全修補hash保留。報告 `/tmp/xw_codepass10_20261107/REPORT.md`；固定b/c/d、官方build.py/SW/發布目錄未動，未打包部署公告。
- 剩餘：O(n²)碰撞、所有目的地滿時原每次更新重選掃描、bh/堵路滯留、實機效能與存讀/金融對帳、試煉強度缺合法實戰證據。126僅有效局部切片，不是整檔通過。


## 第十一批（2026-11-07T16:22:19.917510+08:00 Asia/Taipei）：來源only，固定e不動
- g23餐宿不搶active手動令；新移動取消舊睡眠續工，手動攻擊保留、結束後恢復train/jobB。7組離線真函式門檻；一般「點練武變待命」未重現、不當圖中根因。
- g20 v157Kb有位移且task=move時補needRepath，修已接受move後再擊退會清路徑丟令；實際A*/碰撞時間推進5組，原擊退保留。**輸入延遲仍獨立未解，玩家完整根因未證。**
- g23同簇顯示idx改依id，微交叉slot跳19→0；全部名牌保留，密集壓縮/真抖動未驗。
- econ_promote共享HTML生成去重並僅注入職位rank pane：4層整段4→1，報名16→4，核准4→1；原跨tab外溢改為rank內；不是CSS藏掉，事件與資產函式不動。職位篩選按鈕無效另待事件查核。
- 建築錯選已查晚裝footprint/AABB/深度鍵，未原圖opaque點重現；建築閃爍/黃光來源未定，尚未修；怪推擠兩路保留，不關碰撞。
- 報告 `/tmp/xw_codepass11_20261107/REPORT.md`；3改檔完整hash見 `/tmp/xw_codepass11_20261107/changed_hashes.json`，332來源另329相同，固定b/c/d/e及d/e發布copy不變；無瀏覽器/headless/CDP/改port隧道，無build/包裝/部署公告。


## 第12批 2026-11-07T16:27:03.347066+08:00 Asia/Taipei（僅來源、未包／未部署）
- 建造左鍵／短點直接進既有放置入口，右鍵／長按詳情；守門及正式放置付費不變。
- 職位篩選確證共用pane缺handler及roster換節點丟listener，改既有單一document代理；原任命權限不變。真函式隔離16例＋替換檢查通過，非實機UI。
- 詳報 /tmp/xw_codepass12_20261107/REPORT.md；332輸入僅g23.js、econ_rank.js變，其他330及第11批均保留。
- 新待查t1372u暫停/宗門同顯與裁切；t1374u入館反覆進出（未解，不能以餐宿修補代替）。輸入延遲、密集名牌、錯選/閃爍/光圈及練武待命仍保留未驗。


## 第13批 2026-11-07T16:30:36.261878+08:00 Asia/Taipei（source only）
- 暫停確證事務插在scroll body外與pane缺pause CSS顯隱，最小修g23插入點＋g21 scoped顯隱。真生成祖先鏈／既有5tab切換通過；實機裁切/滾動未驗，不臆測modal互斥。
- 入館循環與練武待命未重現、不改：定向真函式120秒訓練穩定、損壞/修復、已醒恢復案例通過，不含完整AI/combat/疲勞時序，不能宣稱循環已解。
- t1375u快速移動僅地圖選目的地規格列下批，保留費用/人數/安全/聯機gate，本批未改。其他延遲／錯選強光閃爍／名牌密集仍待查。
- 報告 /tmp/xw_codepass13_20261107/REPORT.md；332相對第12批僅g21/g23二改，其餘330與前修保留，固定包/發布copy不動，未build/package/部署/公告。


## 第14批 2026-11-07T16:34:50.462965+08:00 Asia/Taipei（source only）
- 快速移動取消常駐，僅開大地圖列既有目的地；仍走當時晚裝mapStpStart。g7外點關圖例外加mapstp，費用/人數/境界/安全/聯機/pending及金融鎖保持。
- 真函式測試30次重開/取消、七拒絕後重試無殘run通過；非實機UI/FPS/全遊戲不卡死／存讀／金融transaction驗收。
- 建築錯選只讀追到econ_art晚裝footprint優先/AABB/depth；原圖點位與opaque遮擋未重現，不改選取/選框。t1376u建築文本/境界建造門檻列下一批；入館循環/練武待命、延遲/強光閃爍/密集名牌仍保留未解。
- 報告 /tmp/xw_codepass14_20261107/REPORT.md；332僅map_stele_tp.js/g7.js變、其他330與11–13前修保留。固定包/發布copy不動，未build/package/部署/公告。


## 第15批 2026-11-07T16:39:47.847814+08:00 Asia/Taipei（source only）
- 純中文校正：移除無consumer的武道館「突破武師必需」兩處；閉關「各自修煉」、3.5為基礎非固定實得；吐納說明取最高有效級不疊加；建造詳情列明宗門目前/歷史peak解鎖，不是僅主角。
- 正常宗門未達門檻仍能蓋未重現；真card/direct/place/client/host均拒絕，達標重試/取消/host finally清理通過。主角低但宗門/歷史達標原規則允許；開發例外另列，不猜玩家。新建門檻和既有館舍使用不混同，不改玩法/資產/所有權/安全。
- 報告 /tmp/xw_codepass15_20261107/REPORT.md；332僅g18/g20/g23文字生成變，其餘329及11–14保留。未build/package/部署/公告、固定包及copy不變。
- t1378u泛稱靈石/◆列下一批，不猜四個全品級；僅下中上、衝突公庫下品為準另一筆備份、不相加不max/min，金融conflict保護維持。延遲/錯選強光閃爍/密集名牌/入館循環仍未解。


### 16:39 Asia/Taipei 追加待辦 t1379u（未擴第15批）
依當前境界合理收支：三品頂欄問題處理後，可同線盤點各境界既有收入、支出、物價與靈石換算；先提出調整方案待用戶確認，再改數值。不盲拉收入／倍率，不改既存資產。維持下／中／上=1:100:10000與金融安全鎖。本次只記待辦、未分析或改數值。


## 第16批 2026-11-07T16:43:10.408423+08:00 Asia/Taipei（source only）
- 確證頂欄原泛稱res.lingshi＋vault四品◆，不是猜色塊；改正常下中上明確標籤、隱藏保留legacy更新id、歷史ji只警示待核對不轉換刪除，手機不全藏。
- 真g7→g23→grade UI定向150次更新資產/backup/conflict/pending前後同；原raw-load plan公庫5勝舊99且另備份、不相加max/min，金融UI外原碼全同。內部ji及既有支付換算保留，非完成全系統三品遷移。
- 報告 /tmp/xw_codepass16_20261107/REPORT.md；332僅part1/econ_grade顯示段二改，其餘330與前15批保留，固定包/copy不動，未build/package/部署/公告。圖給定路徑Read失敗，來源與離線為證、實機未驗。
- t1380u取消僅弟子間推擠列下批優先，戰鬥擊退/建築阻擋不動；t1379u境界收支盤點/方案待確認在其後。延遲/錯選強光閃爍/密集名牌/入館循環等仍保留未解。


## 第17批 2026-11-07T16:47:26.428483+08:00 Asia/Taipei（source only）
- 依t1380u取消普通disciple-disciple互推：g3基礎、g17替換、cult額外分離三層窄skip，np玩家化身/其他pair/地形/技能擊退均保留。90例其他pair及callback次序精確等價，密集與命令保留測試通過。
- t1384u平地定向：DD同目的地改後不再被互推遠離；P/D同目的地仍保留約1.336格被分離/舊收尾風險，task已清，不能宣稱全部路線或玩家平台不卡，未改新避讓。輸入延遲/入館循環等不標已解。
- 下一18收費回頂/焦點，點事件後暫停裁切同panel鏈先核對是否同因；任務榜接取無效再後；境界收支方案後排待確認。均未擴本批。
- 報告 /tmp/xw_codepass17_20261107/REPORT.md；332僅g3/g17/cult_unclump三改，其餘329與前16批保留；固定包/copy不動、未build/package/部署/公告。實機/全世界尋路/存讀/FPS未驗。


## 第18批 2026-11-07T16:52:02.045172+08:00 Asia/Taipei（source only，未入包）
- t1381u確證真收費click/change後全財務／行替換丟失nested scroll/focus/draft，econ_core兩真替換點新增局部同步保存恢復；提交欄位依原setter結果、不恢復舊draft，不跨root/tab焦點。真委派→setter→HTML→replacement定向測試通過，改前後econ資料結果相同；費率／資產／pending／conflict不改。
- t1383u點事件後暫停區窄裁切仍未確證，未新改；第13批保留，沒有實機或玩家時序重現，不標已解。附件新路徑讀取不到，未宣稱看過。
- 332僅econ_core一改、其餘331及前17批保留；固定包/copy不動，未build/package/部署/公告。11–18均未入固定e。報告 /tmp/xw_codepass18_20261107/REPORT.md。
- 任務榜接取等留待parent續派；輸入延遲／玩家弟子卡住／錯選閃爍強光／密集名牌仍未解，入館循環未重現；切磋扣血已取消不處理。本批完即停，不自行續審。


## 第19批 2026-11-07T16:54:51.602450+08:00 Asia/Taipei（source only，未入包）
- t1382任務榜接取：真村quest無q.id/q.qn卻被拿來當key、且沒有take/self委派listener，確證修econ_task來源映射及一次性委派，仍走原acceptQuest(v.id)與network authority。不同同名任務不合併，成功按狀態禁用，拒絕中文提示可重試。真生成／委派／accept及host轉送定向測試通過，資產與金融不改。
- 332僅econ_task一改，其餘331及第18以前保留。固定包/copy不動，未build/package/部署/公告；11–19尚未入包。實機UI／聯機傳輸／存讀未驗。報告 /tmp/xw_codepass19_20261107/REPORT.md。
- t1388死亡／逃走下一批先找既定規則，本批未查未改；切磋扣血維持取消，境界收支先提案。18事件後裁切及其餘延遲／卡住等仍未解，不冒稱完成。


## 第20批 2026-11-07T16:58:11.179878+08:00 Asia/Taipei（0來源修改，未修復／未入包）
- t1388真源確證：death開且非coop時，元嬰前非免逃敵人cultEnemyLethal直接archive，略過chance／已flee判定。18例真致死鏈均0次抽rnd、hp歸零後回15%入cultFled；正hp低血才有概率逃走；boss與flag-off/coop正常原擊殺、元嬰真元神分支保持。
- 舊CULT_SCHEMA說元嬰前全員不死；現程式自述同時有『歸零即死』及『20～30%致死逃走』，未找回20～30%人類原始訊息；t1388只否定100%。不猜政策，未接新chance／未全改死亡。需確認一般敵人歸零直接擊殺或沿既有chance，與玩家弟子/元神/地圖分開。
- 332來源全部與19相同，fixed包/copy未變；未build/package/部署/公告。報告 /tmp/xw_codepass20_20261107/REPORT.md。這是現狀證據，不是修補PASS。
- 下一排隊t1389藏書閣未獲得庫存來源，本批未查；切磋扣血取消不做；收支平衡後續提案待確認。其他未解保留。


## 第20b 2026-11-07T17:00:34.244326+08:00 Asia/Taipei（source修補、未入包）
- parent補較晚原話／既有修補意圖：完整扣傷、重傷不回血、可追死；兩三成不是user授權數字。cult_death普通致死return false回既有kill鏈，不再hp0補15% archive；正hp機率及數值不改。玩家弟子／boss／元神／地圖政策不動，既有fled不清。
- 真g3+既有drop/corpse/event wrapper+late cult定向比較通過：18致死與原正常擊殺一致、正hp兩機率分支精確保持、已逃可追死、boss元神守門保持；同dead再傷害未重複結算。非完整掉落／金融consumer與實機驗收。
- 332僅cult_death一改，其餘331及11–19保留；固定包/copy不動，未build/package/部署/公告。報告 /tmp/xw_codepass20b_20261107/REPORT.md。
- 下一藏書閣來源→掉落盤點→境界收支提案；錄影黃色掉落來源未知，不歸因。既有fled回歸清loot標記風險留盤點，不清資產；切磋扣血取消仍不做。


## 第21 2026-11-07T17:04:11.806505+08:00 Asia/Taipei（source修補，未入包）
- t1389確證：econ migration在gf開/live hook到位/未seeded時把全300門目錄按low3/mid2/high1寫真庫存，且可借。現seed含force入口停止灌值，未取得no-stock，晚裝館藏0卷不畫借閱鈕。
- 舊庫存／loan／owned／私有metadata全保留，只標legacy-unverified，不猜／不清舊資產；新Store只表示recorded-deposit，舊未知不漂白。真300目錄→migration→Store/Borrow/Return/Withdraw→晚裝panel定向測試及兩檔syntax通過；非真存讀／UI驗收。
- 332僅econ_gf/cult_gf兩改，其餘330及20b所有前修保留；固定包/copy不動，未build/package/部署/公告。報告 /tmp/xw_codepass21_20261107/REPORT.md。
- 下一t1392物品2%已定，不連動食物／貨幣／XP，特殊保底／重複另查；本批未擴。切磋扣血仍取消，收入方案後排待確認，其他未解保留。


## 第23 2026-11-07T17:13:16.394363+08:00 Asia/Taipei（source修補，未入包；非全部獎勵全面2%）
- t1392主kill/dgKill的g12材料／裝備與econ_drop地面裝共用一次rnd<.02 gate，成功沿既有池；不可每pool另roll。舊force不繞過2%，正常food/currency/XP公式不改。
- 真確證：2500ms去重過期同dead回調再掉、直接同dead kill重算食物與統計。現channel runtime去重與晚裝kill/dgKill dead guard，邊界及重入定向測試通過。合法fled／body revive只reset gate不發獎，20b不補血與所有資產保留。
- **殘留**：通關boss／寶箱／任務保底報酬未砍；map獨立至寶／功法API與map_dungeons通關非共用gate，不說全怪物來源都完成2%。需再窄核動態接線／保底邊界，不宜漏報。
- 332僅g12/econ_drop/econ_gear/cult_death四改，固定包/copy不動，未build/package/部署/公告。報告 /tmp/xw_codepass23_20261107/REPORT.md；未實機UI／存讀／聯機驗收。收入方案後排僅提案，切磋扣血取消維持。


## 第24 2026-11-07T17:16:07.424032+08:00 Asia/Taipei（source修補，未入包）
- 獨立map kill至寶／功法API被呼叫時共用第23單次2% gate及各自一次channel，不新增主kill呼叫／玩法。12個先後順序／邊界、直接API／grant回調重入定向通過；gate拒絕不進地圖pool。
- 已攜帶資產照轉、不受2%扣；原同carrier重入會fallback創第二件，現runtime占位避免複製且保留id/數值。通關／寶箱／任務／非kill保底不動。map-only原pool條件可能令實際授予低於2%，不冒稱每池恰2%。
- 332僅g12/map_enemies/map_gongfa三改，23/20b/21全保留，固定包/copy不動，未build/package/部署/公告。報告 /tmp/xw_codepass24_20261107/REPORT.md；after_source_manifest作後續封裝基線。未實機boot/UI/存讀/FPS。
- 本批收束可轉封裝，未展開收入／其他未解；切磋扣血仍取消，既有bug清單保留。

## 2026-11-07T17:30:32.722326+08:00（Asia/Taipei）第25批 source-only
依t1409取消g3/g17/cuApplySeparate全部單位接觸被動推擠；216配對/層級、10組離線時間推進及terrain/技能擊退定向證據通過。固定f不含本批，未包/部署/實機驗收。採集不服從/輸入延遲與其他卡住仍未解。報告：/tmp/xw_codepass25_20261107/REPORT.md。

## 2026-11-07T17:35:24.030302+08:00（Asia/Taipei）第26批 source-only
右鍵/觸控點資源普通弟子繞過assignJob，舊待命/移動/練武manual lock會restore覆蓋採集；已接回原pipeline與拒絕提示，真選角/投影命中/事件/AI窄回歸通過。不是影片根因定案，左鍵語意未改；固定f不含25/26，未包/實機驗收。報告：/tmp/xw_codepass26_20261107/REPORT.md。
餐飯影片待辦：0–5秒門階前走動/滑開未見入館，1–3秒另女性停約1秒後離開；無個人面板，吃飽日誌不能對應人物，不證完整週期。未擴查餐宿。

## 2026-11-07T17:38:53.350169+08:00（Asia/Taipei）第27批零產品增量
擊殺原已有修為：xv=round(敵表xiu*(1+敵境界*.5))，再走原xiuMul與dualExp分流；24組真主死亡/副本鏈證明有效/重入不重給、正hp逃不給。未新增第二份獎勵；獨立未裝配map API無修為consumer不新接。不當全地圖/UI驗收；餐宿仍待查。報告：/tmp/xw_codepass27_20261107/REPORT.md。

## 2026-11-07T17:43:03.273431+08:00（Asia/Taipei）第28批 source-only／餐宿仍未全解
確證正常job=gather/task=null被食堂工作detour排除，已最小放行非守衛/跟隨工作，保留手令/安全/價格/時間。真A*/LOS/碰撞與3人障礙步行、單次扣食/恢復工作證據通過。重要缺口：閒暇吃完即走，兩餐飲流程均未enterBuildingUnit/餐位預約；未擅造席位，影片門口個體仍無法對應，餐宿案不關。報告：/tmp/xw_codepass28_20261107/REPORT.md。
擊殺修為t1416「實際遊玩未觸發」優先待查真晚裝/滿條/顯示，27高上限adapter不關案；隱形怪排後，未擴本批。


## 第29批（2026-11-07 Asia/Taipei）：擊殺修為實玩未觸發仍未解
產品來源零改動；真need/cap/advance/傷勢/離線化身/顯示10例定向：大境界溢出上限可零增且capped false，base MAX_REALM6與Cult cap11並存；真below-cap亦可因萬位縮寫或未跨整數看似無變。均非玩家根因定案，不放寬上限／不加倍。真多人與玩家存檔未驗，最小補件為可重現擊殺前存檔匯出。修為相關來源與固定f相同（g3/g23差異僅分離/用餐）。報告 /tmp/xw_codepass29_20261107/REPORT.md；餐宿及隱形怪另待，不關案。


## 第30批（2026-11-07 Asia/Taipei）：t1415隱形怪仍未解
來源零改動；窄追野外/副本drawBeast、本體晚裝wrapper、座標/探索/命中、程序圖與canvas快取，416本體分支及2探索資格離線記錄測試通過，但不驗真像素/全draw/真場景/多人，不足排除玩家回報。未確證合法觸發，不猜隱身技能或資產失敗。最小補件：隱形怪仍攻擊時、保場景選角的存檔，可與29同份避免重索。報告 /tmp/xw_codepass30_20261107/REPORT.md；t1417宗師壓制留下一批。


## 第31批（2026-11-07 Asia/Taipei）：宗師壓制煉氣未定因
來源零改動；確認宗師3<煉氣4，真supp方向95%/105%未倒；境界壓制字飄守方而非施壓者。另確認名牌v51屬性估境/v162神識與真戰鬥e.realm口徑分離，未取得玩家該敵人state不能斷根因；不改倍率、不全面替換另有AI consumer的v51Realm。6例離線倍率/提示及估境測試通過非實戰驗收。報告 /tmp/xw_codepass31_20261107/REPORT.md。可與29/30共用現場存檔，不關案。


## 第32批（2026-11-07 Asia/Taipei）：戰鬥優先級／門BOSS source修補未入g
真右鍵事件已成功換attack，舊cult_unclump._cuEsc仍令fightStep return且沿舊dv移動；新成功手動attack清grace與舊期望速度，玩家/弟子/np前後6例立即向新敵。門BOSS xfboss沿既有80%玩家相對盾回充、不再被動回血，其他怪原樣。糾正前另確證元神死體留陣列仍攻擊／搶點，僅dead AI/點擊guard，保留owner復活；非影片主因、不關隱形／無修為案。報告 /tmp/xw_codepass32_20261107/REPORT.md；固定g未改，未build部署、未實機。
