# 第32批：移動改攻擊優先級＋仙凡門BOSS回復

## 兩項最高優先：已修source，未入包
### 1. 移動中新攻擊被舊移動抑制（確證）
- 真原因不是點不到怪：右鍵事件→enemyAt→setTask 已成功把task換成帶man的attack，但cult_unclump仍保留舊移動的 `_cuEsc`（commandMove約2.2秒、setTask move約2秒）。
- cuMoveOrder把未過期 `_cuEsc` 當移動令；fightStep直接return，chase也不執行。舊dvx/dvy仍在，所以角色繼續向舊方向移動，即使面板／task已指向敵人。這能精確重現「先後退，再選怪攻擊卻仍走舊方向」的優先級缺陷；不是宣稱所有輸入延遲已解。
- 最小修：晚裝cult_unclump.setTask在**新手動attack真正被底層接受、u.task===t、非既有豁免**後，清掉舊 `_cuEsc` 與舊期望速度dvx/dvy。下一個AI步進即可追新敵，不等原路走完／grace到時。
- 沒清實際vx/vy、技能擊退、stun、冷卻、飛行／踏仙梯／逃走豁免或尋路規則；未把左鍵改攻擊。底層拒絕／送網路intent但未本地接單時，不因這個post-check強制改令。

### 2. 仙凡之門BOSS：護盾回復80%，血量不回復（已依新授權修）
- 真晚裝在cult_enemy.js；g23舊BATCH2100_ENEMY_GQ有立即return，不能把它當仍跑第二套回充。沿現有脫戰觸發、權威、受擊／逃走與原回充節奏。
- 既有註解／參數的80%指**同境玩家護盾公式倍率**，不是一次瞬補80%或固定只補至80%。本批保留既有倍率，不再額外乘0.8變64%，也不新增回復觸發。
- 僅對type==='xfboss'禁用此被動回血；盾上限／回充、其他怪物回血與數值不動。realm4示例玩家盾125，BOSS盾100；同refill=2，半秒回盾25＝每秒50，玩家每秒62.5的80%。HP100保持100；相同條件xfguard仍回HP至103.6。

## 在收到優先級糾正前已確證並完成的獨立窄保護
不是影片根因、不用它替代上述兩項：真元神出竅會把敵人本體dead=true/hp=0，但留S.enemies供cultOwnerOf復活。舊最終updateEnemy仍把此死體送入下層AI；基底enemyAt也可先命中死體，外層直接return，搶走附近活元神點擊。
- 由真makeEnemy→真dmgEnemy/kill hook→真cultSpawnYuanShen→6層有效敵人update包裝／真移動與dmgUnit定向時間推進重現：3遊戲秒內死體仍造成40.5444傷害，點擊先取到死體。
- 最小保護：最後cult_enemy.updateEnemy先拒絕dead；g7 enemyAt略過dead。保留本體在陣列、所有資產／owner關係，不清敵或改復活／元神死亡經濟；元神逃脫後原本體仍按原規則復活且恢復合法攻擊。
- 修後同例死體造成0傷害、不再搶點；元神與本體皆未被私自刪除。這不是t1424已糾正主因，亦不是聲稱隱形怪／無修為已解。後續已停止擴渲染分支。

## 真事件／時間步進證據
`node /tmp/xw_codepass32_20261107/attack_checks.cjs`：6個前後對照（玩家、普通弟子、np玩家化身各一）。
- 真pointerdown→mouseDown→rightClick、實際投影enemyAt、手令setTask／移動包裝、完整cult_unclump與真runTask/chase/followPath/moveEntity；不是僅直接注入command。
- 修前：角色先從x5移到5.3；右鍵選x3敵人後task已attack/man=1，但下一tick仍dvx=+3、走到5.6，1.1秒後8.6、0次攻擊。
- 修後：同次命令下一tick立即dvx<0向敵人；玩家/化身回到x5，普通弟子沿原圍攻槽位路徑移動；1.1秒內均有1次近戰端點觸發。
- 普通弟子仍沿原圍攻槽位，不改射程／頻率；np是離線化身形態fixture，不是假裝驗過真多人。
`node /tmp/xw_codepass32_20261107/checks.cjs`：死體／復活前後與BOSS／普通衛兵回復前後共4組對照通過。
- 真盾公式與完整cult_enemy模組；受擊中仍不啟動既有脫戰回充。不同例沿原death／drop鏈，不放寬上限、不撤2%與非全逃規則。
- 三改檔語法通過（g7僅必要HTML/IIFE片段包裝）。未跑廣泛歷史suite。

測試限制：直達flat-map pathTo/LOS、無關世界／NPC與melee傷害端點為明示adapter；未裝整遊戲所有晚裝UI／網路／狀態，不能當實機操作驗收。核心異常取真晚裝helper、手令與原始期望速度配合物理步進重現，沒有拿健康高上限fixture再次自證正常。初次fixture曾漏RNG/誤截followPath，已修測試搭建；產品失敗前後證據各附prepatch log。

## 最近舊來源比對
- 針對11個相關戰鬥檔與可得固定c快照比對，見combat_comparison.json及3份since_c.diff，不全面審計。
- c→g的g4基本戰鬥consumer相同；c與本批前的cuMoveOrder／setTask移動grace段也相同。故此優先級缺陷是可得c/g共同保留的問題，**無法宣稱由g新引入或玩家「以前正常」版本就是c**。
- c→g已確認普通致死不補血轉逃與2%防重等既定修正保留，不回滾。真正最近交付g的本批前來源即31基線。

## 未解／未驗與保全
- 玩家親述優先級序列已找到等價離線缺陷並修source；尚未在玩家真存檔／真UI驗收。不能承諾所有戰鬥退化已解。
- 無修為與隱形怪實際場景、境界顯示／真realm口徑仍保留，不用死體例或這次攻擊優先級冒充全部關案。未採信兩份廢棄watch OCR／數字，也沒有觀看／抽影片。
- 332來源僅3檔增量；before/after_source_manifest、changes.patch、changed_hashes完整附檔。25取消被動互推、26右鍵採集、28工作用餐與更早全部修補保留。
- 固定b–g ZIP逐SHA不變；官方sharedsite203檔、build.py/SW不動。沒有build／包／部署／公告／browser／headless／CDP／port繞路。金融存檔／pending／conflict保護未改。
- 這是**source修補，不在已交付g**。完成停手，待parent決定下一步。

## 改檔完整SHA256
|來源|after SHA256|
|---|---|
|`_dev/v45/cult_enemy.js`|`1e43d557da450ab05f61630c1cad37d9e0b6561fde27041ef8c41619eab2d701`|
|`_dev/v45/cult_unclump.js`|`56ac38c34ee573b5c51404b60a0f1adc80f8451c7514d08664396ce40472e1c6`|
|`_dev/v45/g7.js`|`50fc7f9df6ed890a5b6b5e10ca0998009491f3d1672a2c904d81ff00f14c2fd1`|
